const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
//const passport = require('passport');

// Load User model
const User = require('../models/User');

//const { forwardAuthenticated } = require('../config/auth');

// Login Page
//router.get('/login', forwardAuthenticated, (req, res) => res.render('login'));

// Register Page
router.get('/register', (req, res) => res.render('register'));

// Register
router.post('/register', (req, res) => {
  const { title, slug, description, price, active, tags} = req.body;
  let errors = [];

  if (!title || !slug || !description || !price || !active || !tags) {
    errors.push({ msg: 'Por favor, insira todos os campos' });
  }

  
  if (description.length < 3) {
    errors.push({ msg: 'A descrição deve ter pelo menos 3 caracteres' });
  }

  if (errors.length > 0) {
    res.render('register', {
      errors,
      title, slug, description, price, active, tags
    });
  } else {
    User.findOne({ title: title }).then(user => {
      if (user) {
        errors.push({ msg: 'Produto já existe' });
        res.render('register', {
          errors,
          title, slug, description, price, active, tags
        });
      } else {
        const newUser = new User({
          title, slug, description, price, active, tags          
        });

        bcrypt.genSalt(10, (err, salt) => {
          bcrypt.hash(newUser.title, salt, (err, hash) => {
            if (err) throw err;
            newUser.title = hash;
            newUser
              .save()
              .then(user => {
                req.flash(
                  'sucesso_msg',
                  'Produto cadastrado com sucesso'
                );
                res.redirect('/');
              })
              .catch(err => console.log(err));
          });
        });
      }
    });
  }
});

// Login
router.post('/', (req, res, next) => {
  passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/',
    failureFlash: true
  })(req, res, next);
});

// Logout
router.get('/logout', (req, res) => {
  req.logout();
  req.flash('success_msg', 'Você está desconectado');
  res.redirect('/');
});

module.exports = router;