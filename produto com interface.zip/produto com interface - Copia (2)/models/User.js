const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    title: {
        type: String,
        require:true,
        trim: true
    },

    slug: { //ex: video game = video-game
        type: String,
        require:true,
        trim: true,
        index: true,
        unique: true
    },

    description: {
        type: String,
        require:true,
    },

    price: { 
        type: Number,
        require:true
    },

    active: {
        type: Boolean,
        require:true,
        defaut: true
    },

    tags: [{
        type: String,
        require:true
    }]
});

const User =  mongoose.model('User', UserSchema);
module.exports = User;